<html>
    <header>
        <title> Registro Editorial </title>
    </header>
    <body>
        <form method="post" action="crud.php">
            Nombre:
            <input type="text" name="nombre" required><br>
            <button type="submit" name="editorial">Registrar</button>
        </form>
    </body>
</html>